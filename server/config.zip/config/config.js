

const secretKey = "4D635166546A576E5A7234753778217A";


module.exports = {
    secret: secretKey,
  };